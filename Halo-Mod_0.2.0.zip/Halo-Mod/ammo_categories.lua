--[[

ata:extend(
{
  {
    type = "ammo-category",
    name = "halo-plasma-rifle-ammo",
    subgroup = "ammo-category"
  },{
    type = "ammo-category",
    name = "halo-plasma-pistol-ammo",
    subgroup = "ammo-category"
  },{
    type = "ammo-category",
    name = "halo-needler-ammo",
    subgroup = "ammo-category"
  },{
    type = "ammo-category",
    name = "halo-fuel-rod-ammo",
    subgroup = "ammo-category"
  },

})
]]