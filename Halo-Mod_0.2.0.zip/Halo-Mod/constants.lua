energy_weapons = {"halo-ce-plasma-rifle", "halo-ce-plasma-pistol", "halo-ce-fuel-rod-cannon"} --specifically ones that can overheat

weapon_heating = {}
weapon_heating["halo-ce-plasma-rifle"] = 0.1
weapon_heating["halo-ce-plasma-pistol"] = 0.05
weapon_heating["halo-ce-fuel-rod-cannon"] = 0.15